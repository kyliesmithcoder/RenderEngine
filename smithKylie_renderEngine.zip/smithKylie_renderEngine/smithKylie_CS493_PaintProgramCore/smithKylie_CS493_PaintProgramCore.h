// smithKylie_CS493_PaintProgramCore.h

#pragma once

#ifndef _SMITHKYLIE_CS493_PAINTPROGRAMCORE_H
#define _SMITHKYLIE_CS493_PAINTPROGRAMCORE_H

using namespace System;

namespace smithKylie_CS493_PaintProgramCore {

	public ref class DLL
	{
	public:
		static void _OnInitialize(int nWidth, int nHeight, int nStride, IntPtr pSurface);
		static void _OnFrame(int nWidth, int nHeight, int nStride, IntPtr pSurface);
	};

	class Point {
	public:
		Point();
		Point(float x, float y, float z);
		float x, y, z;
	};

	Point operator+(const Point& a, const Point& b);
	Point operator-(const Point& a, const Point& b);
	//Point operator*(const Point& a, const Point& b);

	typedef Point Vector;

	class Ray {
	public:
		Ray();
		Ray(Point origin, Vector direction);
		Point GetPointAt(float t)const;
		Point origin;
		Vector direction;
	};
	
	class Color {
	public:
		Color();
		Color(float a, float r, float g, float b);
		float a, r, g, b;
	};

	class Camera {
	public:
		Camera(Point fp, float fl, float vw, float vh,
			   Vector right, Vector up, Vector forward,
			   int mode);
		Ray GetRay(float x, float y);
		Point focal_point;
		float focal_length;
		float viewport_width;
		float viewport_height;
		Vector right;
		Vector up;
		Vector forward;
	private:
		int mode;
	};

	class Object;

	class RayHitInfo {
	public:
		float t;
		Ray ray;
		Point point;
		Color color;
		Vector normal;
		Object* pObject;
		Vector tangent;
		Vector reflection;
		Vector refraction;
		Object* pTriangle;
		//Material material;
		//BarycentricCoord baryCoord;
		//TextureCoord textureCoord;
	};

	class Object {
	public:
		virtual bool DoesRayHitYou(const Ray &ray, RayHitInfo &hitInfo)=0;
	};

	class Sphere : public Object {
	public:
		//Sphere();
		Sphere(Point, float, Color);
		bool DoesRayHitYou(const Ray &ray, RayHitInfo &hitInfo);
		Point center;
		float radius;
		Color color;
	};

	class Triangle : public Object {
	public:
		Triangle();
		Triangle(Point, Point, Point, Color);
		bool DoesRayHitYou(const Ray &ray, RayHitInfo &hitInfo);
		Point A, B, C;
		Color color;
		//TextureCoord auv, buv, cuv;
		Vector normal;
	};

	float PerformShadow(RayHitInfo& hitInfo, Point light);
	void PerformLighting(RayHitInfo& hitInfo);
}

#endif
