// This is the main DLL file.

#include <windows.h>
#include <stdio.h>
#include <Math.h>

#include "smithKylie_CS493_PaintProgramCore.h"

using namespace System::Runtime::InteropServices;

int W = 800;
int H = 600;

int ORTHOGRAPHIC = 0;
int PERSPECTIVE = 1;

namespace smithKylie_CS493_PaintProgramCore {

	Camera* camera;

	RayHitInfo hitInfo;

	Ray::Ray() {}

	Ray::Ray(Point origin, Vector direction) {
		this->origin = origin;
		this->direction = direction;
	}

	
	Point::Point() {
		memset(this, 0, sizeof(Point));
	}

	Point::Point(float x, float y, float z) {
		this->x = x;
		this->y = y;
		this->z = z;
	}

	Point operator+(const Point& a, const Point& b) {
		return Point(
			a.x + b.x,
			a.y + b.y,
			a.z + b.z
		);
	}

	Point operator-(const Point& a, const Point& b) {
		return Point( 
			a.x - b.x,
			a.y - b.y,
			a.z - b.z
		);
	}

	Color operator+(const Color& a, const Color& b) {
		Color col_op_plus;
		col_op_plus.a = a.a + b.a;
		col_op_plus.r = a.r + b.r;
		col_op_plus.g = a.g + b.g;
		col_op_plus.b = a.b + b.b;
		return col_op_plus;
	}

	Color operator*(float q, const Color& b) {
		Color col_op_mult;
		col_op_mult.a = q * b.a;
		col_op_mult.r = q * b.r;
		col_op_mult.g = q * b.g;
		col_op_mult.b = q * b.b;
		return col_op_mult;
	}

	Color::Color() {}

	Color::Color(float a, float r, float g, float b) {
		this->a = a;
		this->r = r;
		this->g = g;
		this->b = b;
	}

	int ARGBtoPixel(unsigned int a, unsigned int r, unsigned int g, unsigned int b) {
		return (a<<24) | (r<<16) | (g<<8) | (b);
	}

	void PixelToARGB(unsigned int pixel, unsigned int& a, unsigned int& r, unsigned int& g, unsigned int& b) {
		a = pixel >> 24;
		r = (pixel << 8) >> 24;
		g = (pixel << 16) >> 24;
		b = (pixel << 24) >> 24;
	}

	Color PixelToColor(unsigned int pixel) {
		unsigned int a, r, g, b;
		PixelToARGB(pixel, a, r, g, b);
		return Color(a/255.0f, r/255.0f, g/255.0f, b/255.0f);
	}

	Color ARGBToColor(unsigned int a, unsigned int r, unsigned int g, unsigned int b) {
		return Color(a/255.0f, r/255.0f, g/255.0f, b/255.0f);
	}

	void ColorToARGB(Color color, unsigned int& a, unsigned int& r, unsigned int& g, unsigned int& b) {
		a = (unsigned int)(color.a * 255.0f);
		r = (unsigned int)(color.r * 255.0f);
		g = (unsigned int)(color.g * 255.0f);
		b = (unsigned int)(color.b * 255.0f);
		}

	int ColorToPixel(Color color) {
		unsigned int a, r, g, b;
		ColorToARGB(color, a, r, g, b);
		return ARGBtoPixel(a, r, g, b);
	}

	//int Color = 0xff000000;

	void PutPixel(int* video, int x, int y, int w, int h, int pixel) {
		if (y*w+x < 0 || y*w+x >= w*h) return;
		video[y*w+x] = pixel;
	}

	Camera::Camera(Point fp, float fl, float vw, float vh, 
		           Vector right, Vector up, Vector forward,
				   int mode) {
		this->focal_point = fp;
		this->focal_length = fl;
		this->viewport_width = vw;
		this->viewport_height = vh;
		this->right = right;
		this->up = up;
		this->forward = forward;
		this->mode = mode;
	}

	//Sphere::Sphere() {}

	Sphere::Sphere(Point center, float radius, Color color) {
		this->center = center;
		this->radius = radius;
		this->color = color;
	}

	Triangle::Triangle() {}

	Triangle::Triangle(Point A, Point B, Point C, Color color) {
		this->A = A;
		this->B = B;
		this->C = C;
		this->color = color;
	}

	Object* objects[100];

	
	
	float RestrictRange(float x, float min, float max) {
		return (x < min) ? (min) : (x > max ? max : x);
	}

	float RangeMap(float x, float min1, float max1, float min2, float max2) {
		//return RestrictRange(
		return min2 + (((x - min1) / (max1 - min1)) * (max2 - min2))/*, min2, max2*/;
	}

	Vector Normalize(Vector &vector) {
		Vector r;
		float magnitude = sqrt(
			(vector.x * vector.x) + 
			(vector.y * vector.y) + 
			(vector.z * vector.z)
			);

		r.x = vector.x / magnitude;
		r.y = vector.y / magnitude;
		r.z = vector.z / magnitude;

		return r;
	}

	float DotProduct(Vector vec_a, Vector vec_b) {
		float dot = (vec_a.x * vec_b.x) +
					(vec_a.y * vec_b.y) +
					(vec_a.z * vec_b.z);
		return (dot < 0.0f) ? 0.0f : dot;
	}

	Point Ray::GetPointAt(float t) const{
		Point result;
		result.x = this->origin.x + t * this->direction.x;
		result.y = this->origin.y + t * this->direction.y;
		result.z = this->origin.z + t * this->direction.z;
		return result;
	}

	Ray Camera::GetRay(float x, float y) {
		Vector direction;
		Vector origin;

		//origin.x = (this->focal_point.x + (x * (W/2) * this->right.x) + (y * (H/2) * this->up.x));
		//origin.y = (this->focal_point.y + (x * (W/2) * this->right.y) + (y * (H/2) * this->up.y));
		//origin.z = (this->focal_point.z + (x * (W/2) * this->right.z) + (y * (H/2) * this->up.z));
		
		//direction = this->forward;

		//return Ray(origin, direction);

		if(this->mode == 0) {
			origin.x = (this->focal_point.x + (x * (W/2) * this->right.x) + (y * (H/2) * this->up.x));
			origin.y = (this->focal_point.y + (x * (W/2) * this->right.y) + (y * (H/2) * this->up.y));
			origin.z = (this->focal_point.z + (x * (W/2) * this->right.z) + (y * (H/2) * this->up.z));
		
			direction = this->forward;

		} else if(this->mode == 1) {
			direction.x = (this->focal_point.x + (this->focal_length * this->forward.x) + x * (this->viewport_width / 2.0f) * this->right.x + y * (this->viewport_height / 2.0f) * this->up.x) - this->focal_point.x;
			direction.y = (this->focal_point.y + (this->focal_length * this->forward.y) + x * (this->viewport_width / 2.0f) * this->right.y + y * (this->viewport_height / 2.0f) * this->up.y) - this->focal_point.y;
			direction.z = (this->focal_point.z + (this->focal_length * this->forward.z) + x * (this->viewport_width / 2.0f) * this->right.z + y * (this->viewport_height / 2.0f) * this->up.z) - this->focal_point.z;
		
			origin = this->focal_point;
		}
		
		direction = Normalize(direction);

		return Ray(origin, direction);
	
	}

	bool Sphere::DoesRayHitYou(const Ray& ray, RayHitInfo& hitInfo) {
		float a = (ray.direction.x * ray.direction.x) + (ray.direction.y * ray.direction.y) + (ray.direction.z * ray.direction.z);
		float b = 2.0f * (ray.origin.x - this->center.x) * ray.direction.x +
			      2.0f * (ray.origin.y - this->center.y) * ray.direction.y +
				  2.0f * (ray.origin.z - this->center.z) * ray.direction.z;
		float c = ((ray.origin.x - this->center.x) * (ray.origin.x - this->center.x)) +
				  ((ray.origin.y - this->center.y) * (ray.origin.y - this->center.y)) +
				  ((ray.origin.z - this->center.z) * (ray.origin.z - this->center.z)) -
				  (this->radius * this->radius);
		float d = (b * b) - 4.0f * a * c;

		if(d < 0.0f) return false;

		
		float e = sqrt(d);
		float t1 = (-b - e) / (2.0f * a);
		float t2 = (-b + e) / (2.0f * a);

		if(t1 <= 0.0f && t2 <= 0.0f) return false;

		float t = (t1 > 0.0f && t1 < t2) ? (t1) : (t2);

		hitInfo.t = t;
		hitInfo.point = ray.GetPointAt(t);
		hitInfo.color = this->color;
		hitInfo.pObject = this;
		hitInfo.ray = ray;
		hitInfo.normal = Normalize(hitInfo.point - this->center);
		//hitInfo.tangent = TangentVector(ray.direction, hitInfo.normal);
		

		return true;
	}

	bool Triangle::DoesRayHitYou(const Ray &ray, RayHitInfo &hitInfo) {
		float dot = (ray.direction.x * this->normal.x) +
					(ray.direction.y * this->normal.y) +
					(ray.direction.z * this->normal.z);
		if (dot > 0.0f) return false;
	
		double a = this->A.x - this->B.x, b = this->A.x - this->C.x, c = ray.direction.x, d = this->A.x - ray.origin.x;
		double e = this->A.y - this->B.y, f = this->A.y - this->C.y, g = ray.direction.y, h = this->A.y - ray.origin.y;
		double i = this->A.z - this->B.z, j = this->A.z - this->C.z, k = ray.direction.z, l = this->A.z - ray.origin.z;
	
		double m = f * k - g * j, n = h * k - g * l, p = f * l - h * j;
		double q = g * i - e * k, s = e * j - f * i;
	
		double inv_denom = 1.0 / (a * m + b * q + c * s);
	
		double e1 = d * m - b * n - c * p;
	
		double beta = e1 * inv_denom;
	
		if (beta < 0.0) return false;

		double r = (e * l) - (h * i);

		double e2 = (a * n) + (d * q) + (c * r);
		double gamma = e2 * inv_denom;

		if (gamma < 0.0) return false;
		if (beta + gamma > 1.0) return false;

		double e3 = (a * p) - (b *r) + (d * s);
		double t = e3 * inv_denom;

		if (t < 1.0) return false;

		hitInfo.t = t;
		hitInfo.point = ray.GetPointAt(t);
		//hitInfo.material = this->material;
		hitInfo.pObject = this;
		hitInfo.ray = ray;
		hitInfo.normal = this->normal;
		//hitInfo.tangent = Vector::TangentVector(ray.direction, hitInfo.normal);
		hitInfo.pTriangle = this;
		//hitInfo.baryCoord.alpha = 1.0 - beta - gamma;
		//hitInfo.baryCoord.beta = beta;
		//hitInfo.baryCoord.gamma = gamma;
		//hitInfo.textureCoord.tu = hitInfo.baryCoord.Calculate(
			//hitInfo.pTriangle->auv.tu, hitInfo.pTriangle->buv.tu, hitInfo.pTriangle->cuv.tu);
		//hitInfo.textureCoord.tv = a_hitInfo.baryCoord.Calculate(
			//hitInfo.pTriangle->auv.tv, hitInfo.pTriangle->buv.tv, hitInfo.pTriangle->cuv.tv);
		hitInfo.color = this->color;

		return true;
	}

	bool initialized = false;
	int* VideoMemory = 0;
	int WIDTH=0, HEIGHT=0;

	int NUM_OBJECTS = 2; 

	bool GetNearestHit(const Ray& ray, RayHitInfo& hitInfo) {
		RayHitInfo nearestHit;
		nearestHit.t = 99999.0f;
		bool bHit = false;
		for(int n = 0; n < NUM_OBJECTS; n++) {
			Object* pObject = objects[n];
			if(pObject == 0) continue;
			RayHitInfo localHit;
			if(pObject->DoesRayHitYou(ray, localHit)) {
				if(localHit.t < nearestHit.t) {
					nearestHit = localHit;
					hitInfo = nearestHit;
					bHit = true;
				}
			}
		}
		return bHit;
	}

	bool GetNearestHit(const Ray& ray, Object* object, RayHitInfo& hitInfo) {
		RayHitInfo nearestHit;
		nearestHit.t = 99999.0f;
		bool bHit = false;
		for(int n = 0; n < NUM_OBJECTS; n++) {
			Object* pObject = objects[n];
			if(pObject == 0) continue;
			if(pObject == object) continue;
			RayHitInfo localHit;
			if(pObject->DoesRayHitYou(ray, localHit)) {
				if(localHit.t < nearestHit.t) {
					nearestHit = localHit;
					hitInfo = nearestHit;
					bHit = true;
				}
			}
		}
		return bHit;
	}

	// LIGHTING
	//////////////////////////////////////////////////	

	Point light(0, 0, -500);

	float PerformShadow(RayHitInfo& hitInfo, Point light) {
		float shadow_intensity = 1.0;
		Ray shadow;
		shadow.origin = hitInfo.point;
		//shadow.direction = Normalize(Vector(light.x - hitInfo.point.x, light.y - hitInfo.point.y, light.z - hitInfo.point.z));
		shadow.direction = Normalize(Vector(hitInfo.point.x - light.x, hitInfo.point.y - light.y, hitInfo.point.z - light.z));
		if(GetNearestHit(shadow, hitInfo.pObject, hitInfo)) {
			shadow_intensity = 0.2f;
		}
		return shadow_intensity;
	}

	void PerformLighting(RayHitInfo& hitInfo) {

		Vector light_direction = Normalize(Vector(light.x - hitInfo.point.x, light.y - hitInfo.point.y, light.z - hitInfo.point.z));
		float dot01 = DotProduct(hitInfo.normal, light_direction);
		float diffuse_intensity = RestrictRange(dot01, 0.0f, 1.0f);
		Color shadow_color = Color(1.0f, 0.2f, 0.2f, 0.2f);
		Color diffuse_color = hitInfo.color;
		
		Vector halfway = Normalize(Vector(0 + light_direction.x, 0 + light_direction.y, 0 + light_direction.z));
		float dot02 = DotProduct(halfway, hitInfo.normal);
		float specular_intensity = RestrictRange(dot02, 0.0f, 1.0f);
		specular_intensity = pow(specular_intensity, 80.0f);
		Color specular_color = Color(1.0f, 1.0f, 1.0f, 1.0f);

		float showShadows = PerformShadow(hitInfo, light);
		
		Color result; 
		result.a = shadow_color.a + diffuse_intensity * showShadows * diffuse_color.a + specular_intensity * specular_color.a;
		result.r = shadow_color.r + diffuse_intensity * showShadows * diffuse_color.r + specular_intensity * specular_color.r;
		result.g = shadow_color.g + diffuse_intensity * showShadows * diffuse_color.g + specular_intensity * specular_color.g;
		result.b = shadow_color.b + diffuse_intensity * showShadows * diffuse_color.b + specular_intensity * specular_color.b;
		result.a = RestrictRange(result.a, 0, 1);
		result.r = RestrictRange(result.r, 0, 1);
		result.g = RestrictRange(result.g, 0, 1);
		result.b = RestrictRange(result.b, 0, 1);

		
		hitInfo.color = result;		
	}

	void DLL::_OnInitialize(int nWidth, int nHeight, int nStride, IntPtr pSurface) {
		int nActualWidth = nStride / 4;
		WIDTH = nActualWidth;
		HEIGHT = nHeight;
		VideoMemory = new int[WIDTH * HEIGHT];
		initialized = true;

		camera = new Camera(
			Point(0.0f, 0.0f, -200.0f),
			60.0f, WIDTH, HEIGHT,
			Vector(1.0f, 0.0f, 0.0f),
			Vector(0.0f, 1.0f, 0.0f),
			Vector(0.0f, 0.0f, 1.0f),
			PERSPECTIVE
		);

		for(int n = 0; n <= 1; n++) {
			objects[0] = new Sphere(Point(500, 500, 300), 400.0f, Color(1.0f, 1.0f, 0.0f, 0.0f));
			objects[1] = new Sphere(Point(500, -500, 300), 400.0f, Color(1.0f, 1.0f, 0.3f, 0.0f));
			objects[2] = new Sphere(Point(-500, 500, 300), 400.0f, Color(1.0f, 1.0f, 1.0f, 0.0f));
			objects[3] = new Sphere(Point(-500, -500, 300), 400.0f, Color(1.0f, 0.0f, 1.0f, 0.0f));
			objects[4] = new Sphere(Point(0, 800, 350), 370.0f, Color(1.0f, 0.0f, 1.0f, 0.3f));
			objects[5] = new Sphere(Point(800, 0, 350), 370.0f, Color(1.0f, 0.0f, 0.0f, 1.0f));
			objects[6] = new Sphere(Point(-800, 0, 350), 370.0f, Color(1.0f, 0.3f, 0.0f, 1.0f));
			objects[7] = new Sphere(Point(0, -800, 350), 370.0f, Color(1.0f, 1.0f, 0.0f, 1.0f));

			//objects[4] = new Triangle(Point(-1000, -1000, 200), Point(1000, -1000, 200), Point(1000, 1000, 200), Color(1.0f, 0.0f, 0.0f, 1.0f));

			//objects[0] = new Sphere(Point( -50,  130, 500), 400.0f);
			//objects[1] = new Sphere(Point(-205,  100, 500), 400.0f);
			//objects[2] = new Sphere(Point( 290,   90, 500), 400.0f);
			//objects[3] = new Sphere(Point(  30,   30, 500), 400.0f);
			//objects[4] = new Sphere(Point(-280,  -10, 500), 400.0f);
			//objects[5] = new Sphere(Point( 200, -125, 500), 400.0f);
			//objects[6] = new Sphere(Point(-120, -150, 500), 400.0f);
			//objects[7] = new Triangle(Point(50, 50, 50), Point(50, 100, 50), Point(100, 100, 50));
			NUM_OBJECTS = 8;
		}
	}

	void DLL::_OnFrame(int nWidth, int nHeight, int nStride, IntPtr pSurface) {
		int* video = (int*)pSurface.ToPointer();
		int nActualWidth = nStride / 4;

		if(!initialized) {
			_OnInitialize(nWidth, nHeight, nStride, pSurface);
		}

		
		/*for(int n = 0; n < nActualWidth * nHeight; n++) {
			video[n] = 0xff000000;//VideoMemory[n];
		}*/

		for(int y = 0; y < nHeight; y++) {
			for(int x = 0; x < nActualWidth; x++) {
				float xp = RangeMap(x, 0, nActualWidth, -1.0, 1.0);
				float yp = RangeMap(y, 0, nHeight, 1.0, -1.0);
				Ray ray = camera->GetRay(xp, yp);
				if(GetNearestHit(ray, hitInfo)) {
					PerformLighting(hitInfo);
					//Color = 0xffff4d00;
					PutPixel(video, x, y, nActualWidth, nHeight, ColorToPixel(hitInfo.color));
				} else {
					//Color = 0xff2b3ddd;
					PutPixel(video, x, y, nActualWidth, nHeight, 0xffffffff);
				}

			}
		}

	}

}

