﻿namespace smithKylie_CS493_PaintProgram
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._pictureBoxMain = new System.Windows.Forms.PictureBox();
            this._colorDialogColorPicker = new System.Windows.Forms.ColorDialog();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this._pictureBoxMain)).BeginInit();
            this.SuspendLayout();
            // 
            // _pictureBoxMain
            // 
            this._pictureBoxMain.Location = new System.Drawing.Point(0, 1);
            this._pictureBoxMain.Name = "_pictureBoxMain";
            this._pictureBoxMain.Size = new System.Drawing.Size(784, 561);
            this._pictureBoxMain.TabIndex = 0;
            this._pictureBoxMain.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(504, 497);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this._pictureBoxMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MainWindow";
            this.Text = "Aurora Rendering Engine";
            ((System.ComponentModel.ISupportInitialize)(this._pictureBoxMain)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox _pictureBoxMain;
        private System.Windows.Forms.ColorDialog _colorDialogColorPicker;
        private System.Windows.Forms.Button button1;


    }
}

