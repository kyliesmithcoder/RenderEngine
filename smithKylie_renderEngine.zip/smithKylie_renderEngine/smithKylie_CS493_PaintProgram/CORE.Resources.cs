﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace smithKylie_CS493_PaintProgram
{
    namespace CORE
    {
        public class Resources
        {
            public static Image GetImage(string name)
            {
                string path = Application.StartupPath;
                return Image.FromFile(path + name);
            }
        }
    }
}
