﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace smithKylie_CS493_PaintProgram
{
    public partial class MainWindow : Form
    {
        private Bitmap _bmpPrimarySurface = null;
        private Timer _Timer = null;
        private int _AnimationRate = 100;

        public MainWindow()
        {
            InitializeComponent();
            _InitializeSystem();

        }

        void _InitializeSystem()
        {
            _CreatePrimarySurface();

            _Timer = new Timer();
            _Timer.Tick += new EventHandler(_OnFrameTimer);
            _Timer.Interval = _AnimationRate;
            _Timer.Start();
        }

        void _CreatePrimarySurface()
        {
            _bmpPrimarySurface = new Bitmap(
                _pictureBoxMain.Width, _pictureBoxMain.Height,
                System.Drawing.Imaging.PixelFormat.Format32bppArgb
            );
        }

        void _OnFrameTimer(object sender, EventArgs e)
        {
            _OnFrame(_bmpPrimarySurface);
        }

        private void _OnFrame(Bitmap bmp)
        {
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
            System.Drawing.Imaging.BitmapData bmpData = bmp.LockBits(
                rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, bmp.PixelFormat
            );
            IntPtr ptr = bmpData.Scan0;

            smithKylie_CS493_PaintProgramCore.DLL._OnFrame(_pictureBoxMain.Width, _pictureBoxMain.Height, bmpData.Stride, ptr);

            bmp.UnlockBits(bmpData);


            _pictureBoxMain.Image = _bmpPrimarySurface;
        }
        
        private void _buttonApplyPixelAttrib_Click(object sender, EventArgs e)
        {
            /* ****NEED TO FIGURE THIS OUT
            Bitmap IMG = new Bitmap(_pictureBoxMain.Image);
            
            decimal X_POS = _numberUpDownXPos.Value;
            int _X_INT = (int)X_POS;
            decimal Y_POS = _numberUpDownYPos.Value;
            int _Y_INT = (int)Y_POS;
            Color PIX_COLOR = ((Bitmap)IMG).GetPixel(_X_INT, _Y_INT);

            decimal RED_VAL = _numberUpDownRed.Value;
            int _RED = (int)RED_VAL;
            string RED_HEX = _RED.ToString("X2");
            decimal GREEN_VAL = _numberUpDownGreen.Value;
            int _GREEN = (int)GREEN_VAL;
            string GREEN_HEX = _GREEN.ToString("X2");
            decimal BLUE_VAL = _numberUpDownBlue.Value;
            int _BLUE = (int)BLUE_VAL;
            string BLUE_HEX = _BLUE.ToString("X2");
            decimal ALPHA_VAL = _numberUpDownAlpha.Value;
            int _ALPHA = (int)ALPHA_VAL;

            string _HEX_COLOR = RED_HEX + GREEN_HEX + BLUE_HEX;
            Color HEX_TO_COLOR = System.Drawing.ColorTranslator.FromHtml(_HEX_COLOR);      
            
            ((Bitmap)IMG).SetPixel(_X_INT, _Y_INT, HEX_TO_COLOR);
         */
        }       
    }
}
